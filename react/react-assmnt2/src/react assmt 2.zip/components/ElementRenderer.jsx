import React from "react";

function ElementRenderer(){
    return(
        <div>
            <h1>welcome to react</h1>
            <p>this is a paragraph</p>
            <ul>
                <li>i</li>
                <li>like</li>
                <li>pizza</li>
            </ul>
            <a href="https://www.example.com">click here</a>
        </div>
    );
};
export default ElementRenderer;