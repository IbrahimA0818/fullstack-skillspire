import './App.css';
import Timer from './component/timer';

function App() {
  return (
    <div className="App">
    <Timer />
    </div>
  );
}

export default App;
