const express = require("express")
const bodyParser = require('body-parser')
const mongoose = require("mongoose")
const app = express()
const playlist = require('./playlist')

app.use( bodyParser.json() )

app.get("/playlists", async (request,response)=>{
    let playlists = await playlist.find()

    response.send(playlists)
})

app.get("/playlists/:id", (request,response)=>{
    playlist.findById(request.params.id)
        .then((playlist) =>{
            response.send(playlist)
        })
        .catch((err) => response.send(err))
})

app.put("/playlists/:id",(request,response)=>{
    playlist.findByIdAndUpdate(request.params.id, request.body, { new:true })
        .then((playlist)=>{
            console.log("The playlist was updated")

            response.send(playlist)
        })
        .catch((err) => response.send(err))
})

app.delete("/playlists/:id",(request,response)=>{
    playlist.findByIdAndDelete(request.params.id)
        .then((playlist)=>{
            console.log("playlist was deleted")

            response.send("The playlist was deleted.")
        })
        .catch((err) => response.send(err))
})

app.post("/playlists", (request,response)=>{
    let newplaylist = new playlist( request.body )

    newplaylist.save()
        .then((playlist) => {
            console.log("The playlist was saved successfully")
            response.send(playlist)
        })
        .catch( (err) => console.log(err) )
})

app.get("/playlists/:id/songs", (request, response)=>{
    playlist.findById(request.params.id)
        .then ((playlist)=>{
            response.send(playlist.songs)
        })
})

app.post("/playlists/:id/songs",(request, response)=>{
    playlist.findById(request.params.id)
        .then(async(playlist)=>{
            playlist.songs.push(request.body)

            await playlist.save()

            response.send(playlist)
        })
        .catch((err) => response.send(err))
})

app.delete('/playlists/:id/songs/:songId', (request, response)=>{
    playlist.findById(request.params.id)
        .then(async(playlist)=>{
            if (!playlist) {
                return response.status(404).send("Playlist not found");
            }
            
            playlist.songs = playlist.songs.filter((song) => song._id.toString() !== request.params.songId)

            await playlist.save()

            response.send(playlist)
        })
        .catch((err) => response.send(err))
})

let connectionString = "mongodb+srv://ibrahima0818:Nimco6921@cluster0.w9bbjbw.mongodb.net/myplaylistsDB?retryWrites=true&w=majority&appName=Cluster0"


mongoose.connect(connectionString)
.then(()=>{
    const port = 8080

    console.log("Connected to DB")

    app.listen(port, ()=>{
        console.log(`Server is running on port ${port}`) 
    })
}).catch((error)=>{
    console.log(error)
})