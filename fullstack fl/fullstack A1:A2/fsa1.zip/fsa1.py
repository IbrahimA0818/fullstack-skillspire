from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy  

app = Flask(__name__)

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///demo.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(20), nullable=False) 

def __init__(self, first_name, last_name, email, password):
        self.first_name = first_name
        self.last_name = last_name
        self.email = email
        self.password = password


@app.route('/')
def index():
    return render_template("index.html")

@app.route('/adduser', methods=['GET', 'POST'])
def adduser():
    if request.method == "POST":
        firstname = request.form['firstname']
        lastname = request.form['lastname']
        email = request.form ['email']
        password = request.form['password']

    new_user = User(first_name=firstname, last_name=lastname, email=email, password=password)
    db.session.add(new_user)
    db.session.commit()
    return redirect(url_for("retrieveusers"))
@app.route('/retrieveusers')
def retrieveusers():
    users = User.query.all()
    return render_template("users.html", users=users)

# Initialize the database
with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(debug=True)