from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/formdata', methods = ["POST"])
def formdata():
    print(request.form)
    return render_template(
        "data.html",
        Firstname=request.form['Fname'],
        Lastname=request.form['Lastname'],
        Email=request.form['email'],
        City=request.form['city'],
        State=request.form['state'],
        Zipcode=request.form['Zipcode']
    )

if __name__ == "__main__":
    app.run(debug=True)